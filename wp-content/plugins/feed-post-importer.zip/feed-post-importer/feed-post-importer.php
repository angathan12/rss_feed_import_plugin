<?php
/*
Plugin Name: Custom Feed API Endpoint
Description: Fetch and insert the db and display content from an external RSS feed.
Version: 1.0
Author: Paramasivan
*/
?>

<?php
// The schedule filter hook
function isa_add_every_ten_minutes( $schedules ) {
    $schedules['every_ten_minutes'] = array(
            'interval'  => 600,
            'display'   => __( 'Every 10 Minutes', 'textdomain' )
    );
    return $schedules;
}
add_filter( 'cron_schedules', 'isa_add_every_ten_minutes' );

register_activation_hook(__FILE__, 'rss_activation'); 
function rss_activation() {
    if (! wp_next_scheduled ( 'ten_minutes_event' )) {
    wp_schedule_event(time(), 'every_ten_minutes', 'ten_minutes_event');
    }
}

// The deactivation hook
function rss_deactivation(){
    if( wp_next_scheduled( 'ten_minutes_event' ) ){
        wp_clear_scheduled_hook( 'ten_minutes_event' );
    }
}
register_deactivation_hook( __FILE__, 'rss_deactivation' );
 
add_action('ten_minutes_event', 'import_posts_from_feed');

// The WP Cron event callback function
function import_posts_from_feed() {
    $maxItems = 5;
    $i = 0;
    $feed_url = 'https://www.nbcnewyork.com/?rss=y&most_recent=y';  
    $rss = fetch_feed($feed_url);
    // Check for errors
    if (is_wp_error($feed_url)) {
        echo 'Error fetching RSS feed: ' . esc_html($feed_url->get_error_message());
        return;
    }

    $posts = $rss->get_items();

        foreach ($posts as $post) {

            if ($i++ >= $maxItems) {
                break;
            }

            $post_data = array(
            'post_title' => esc_html($post->get_title()),
            'post_content' => wp_kses_post($post->get_description()),
            'post_date' => $post->get_date('Y-m-d H:i:s'),
            'post_status' => 'publish',
            // Add more fields as needed
        );

        // Insert post
        $post_id = wp_insert_post( $post_data );

            // Check if the post was successfully inserted
            if (!is_wp_error($post_id)) {

                // Process media elements (enclosures)
                foreach ($post->get_enclosures() as $enclosure) {                    
                    $img_url = esc_url($enclosure->get_link());     
                }
                $image_url = strtok($img_url, "?");

                // Check if the image URL is valid
                if ($image_url) {
                    // Get the image data
                    $image_data = file_get_contents($image_url);

                    // Generate a unique filename for the image
                    $filename = wp_unique_filename(wp_upload_dir()['path'], basename($image_url));

                    // Save the image to the uploads directory
                    $upload_dir = wp_upload_dir();
                    $upload_path = $upload_dir['path'] . '/' . $filename;
                    file_put_contents($upload_path, $image_data);

                    // Prepare attachment data
                    $attachment = array(
                        'post_title'     => sanitize_file_name(pathinfo($filename, PATHINFO_FILENAME)),
                        'post_mime_type' => wp_check_filetype($filename)['type'],
                        'post_content'   => '',
                        'post_status'    => 'inherit',
                    );

                    // Insert the attachment
                    $attachment_id = wp_insert_attachment($attachment, $upload_path);

                    // Check if the image was successfully added to the media library
                    if (!is_wp_error($attachment_id)) {
                        // Set the post thumbnail (featured image)
                        set_post_thumbnail($post_id, $attachment_id);
                    }
                        
                }      

            }
        }

    $counts = $i-1;

    return new WP_REST_Response($counts.' Posts imported successfully', 200);
}

function check_post_exist($guid) {
    //$guid
}

//add_action( 'isa_add_every_ten_minutes_event', 'import_posts_from_feed' );


// Register custom WP API endpoint
add_action('rest_api_init', function () {
    register_rest_route('feed-post-importer/v1', '/import', array(
        'methods' => 'GET',
        'callback' => 'import_posts_from_feed',
    ));
});


